void randomize_array(double* array, int size, double scale);
void sort_array(double* array, int size);
double sum(double* array, int size);
double stdev(double* array, int size);
void smooth(double* array, int size, double w);
